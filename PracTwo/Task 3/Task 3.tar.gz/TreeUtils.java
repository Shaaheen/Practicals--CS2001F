package PracTwoSource;

import java.util.*;

/**
 * Utility procedures for binary tree structures.
 * 
 * @author Stephan Jamieson
 * @version 25/2/2015
 *
 * Modified by SCRSHA001 at 06/03/2015
 * Shaaheen Sacoor
 * Implemented code for empty methods contain,delete, insert, rotate methods and double rotate methods and added methods from previous assignment
 * Insert and delete are done iteratively for last 10%
 */
public class TreeUtils {
    /**
     * Obtain the height value of the given node.
     * @return 0 if <code>node==null</code>, otherwise <code>node.getHeight()</code>.
     */
    public static int height(AVLTreeNode node) {
        if (node==null) {
            return 0;
        }
        else {
            return heightSetter(node);
        }
    }

    //Returns the height of node given using recursion
    public static int heightSetter(AVLTreeNode nodeToChangeHt){
        if (nodeToChangeHt.hasLeft() && nodeToChangeHt.hasRight()) {
            return Math.max(heightSetter(nodeToChangeHt.getLeft()), heightSetter(nodeToChangeHt.getRight())) + 1;
        }
        else if (nodeToChangeHt.hasLeft()) {
            return heightSetter(nodeToChangeHt.getLeft()) + 1;
        }
        else if (nodeToChangeHt.hasRight()) {
            return heightSetter(nodeToChangeHt.getRight()) + 1;
        }
        else {
            return 1;
        }
    }


    /** 
     * Determine whether the given tree structure contains the given key.
     */
    public static boolean contains(AVLTreeNode node, String keyWord) {
        int key = Character.toUpperCase(keyWord.charAt(0)) - 64;
        if ((node.getKeyWord()).equals(keyWord)){ //if node key is equal to key we want to find then return true
            return true;
        }
        if (key < node.getKey()){ //if key searching for is smaller than current key then try go to the left subtree
            if (node.hasLeft()) { //go down left subtree
                return contains(node.getLeft(), keyWord);
            }
            else { //if there is no subtree and key is smaller than current node key then there can't be key in tree, therefore false
                return false;
            }
        }
        else {
            if (node.hasRight()){ //same as left
                return contains(node.getRight(),keyWord);
            }
            else{
                return false;
            }
        }

    }

    /**
     * Iterative implementation of insert on an AVLTreeNode structure.
     */
    public static AVLTreeNode insert(AVLTreeNode node, String newItem) {
        int key = Character.toUpperCase(newItem.charAt(0)) - 64;
        boolean inserted = false; //used to check if a node has been added yet
        AVLTreeNode currNode = node; //current node working with, changes over each loop
        Stack balanceStack = new Stack<AVLTreeNode>(); //Stack that acts to store the path taken to add object so as to balance tree easily
        balanceStack.add(currNode); //add root node to stack
        while (!inserted){ //while nothing has been inserted keep going
            if (node == null){ //if empty tree then create root node
                node = new AVLTreeNode(key,newItem); //create root node
                return node;//end method and return root
            }
            else if (currNode.getKey() == key){ //if duplicate then do nothing
                currNode.setKeyWord(newItem);
                return node;
            }
            else if (key < currNode.getKey()){ //if new key is smaller than current node key value then try go left
                if (currNode.hasLeft()){ //try go left
                    currNode = currNode.getLeft();
                }
                else{ //if no left value already then add new node here
                    currNode.setLeft(new AVLTreeNode(key, newItem));
                    inserted = true;
                    currNode = currNode.getLeft();
                }
            }
            else if (key > currNode.getKey()){ //similar to above
                if (currNode.hasRight()){
                    currNode = currNode.getRight();
                }
                else{
                    currNode.setRight(new AVLTreeNode(key, newItem));
                    inserted = true;
                    currNode = currNode.getRight();
                }
            }
            balanceStack.add(currNode); //add current node to stack so as to follow path later
        }
        node = checkBalance(balanceStack,node);//rebalance node

        return node;
    }

    //Iteratively delete a node from Tree
    public static AVLTreeNode delete(AVLTreeNode node, String deleteItem) {

        int key = Character.toUpperCase(deleteItem.charAt(0)) - 64; //gets key value of delete item
        Stack<AVLTreeNode> deleteStack = new Stack<AVLTreeNode>(); //delete stack so as to follow delete path
        AVLTreeNode currNode = node; //current working node = root node

        for (int i = 0; i < height(node); i++){ //loop till height of tree reached
            deleteStack.add(currNode); //add node to stack
            if (key == currNode.getKey()){ //if found the node with the same first letter

                //if deleted item is equal the nodes keyword, then delete that node
                if (deleteItem.equals(currNode.getKeyWord())){
                    if (deleteStack.size()  == 1){ //if delete stack is one then we were told to delete root node so have to change root node
                        node = deleteTheNode(currNode); // set root node to new root node
                        return node; //return node straight away
                    }
                    else if (deleteStack.size() > 1){ //if not deleting root node
                        deleteStack.pop(); //delete node at top of stack as that was node to be deleted
                        AVLTreeNode parentNode = deleteStack.peek(); //gets parent node of node to be deleted
                        //Checks which side to set the new node from parent
                        if (parentNode.hasLeft() && !parentNode.hasRight()){ //node to be deleted must be on left side
                            parentNode.setLeft(deleteTheNode(currNode)); //sets left
                        }
                        else if (!parentNode.hasLeft() && parentNode.hasRight()){ //must be on right
                            parentNode.setRight(deleteTheNode(currNode)); //sets right
                        }
                        else if (parentNode.hasLeft() && parentNode.hasRight()){ //if parent of deleted node has two children
                            //to be deleted node has to be either left or right
                            if (parentNode.getLeft().getKey() == currNode.getKey()){ //to be deleted node is on left
                                parentNode.setLeft(deleteTheNode(currNode)); //sets left
                            }
                            else{ //on right
                                parentNode.setRight(deleteTheNode(currNode)); //sets right
                            }
                        }
                    }
                    System.out.println("Deletion completed successfully");
                    break; //delete complete break out of loop

                }
                else{ //if word not in tree
                    System.out.println("Item does not exist in Tree");
                    break;
                }
            }
            else if (key < currNode.getKey()){ //Goes left if to be deleted key is smaller than current node key
                if (currNode.hasLeft()){
                    currNode = currNode.getLeft();
                }
                else{ //if no left value then item doesn't exist in tree
                    System.out.println("Item does not exist in Tree");
                    break;
                }
            }
            else if (key > currNode.getKey()){ //same as left
                if (currNode.hasRight()){
                    currNode = currNode.getRight();
                }
                else{
                    System.out.println("Item does not exist in Tree");
                    break;
                }
            }
        }

        node = checkBalance(deleteStack,node); //rebalances tree before completes operation
        return node;

    }

    //Method that goes through each of the 4 possible cases when deleting a node
    public static AVLTreeNode deleteTheNode(AVLTreeNode toBeDeleted){
        if (!toBeDeleted.hasRight() && !toBeDeleted.hasLeft()){ //if a leaf node then return nothing
            return null;
        }
        else if (!toBeDeleted.hasRight() && toBeDeleted.hasLeft()){ //if it has left node only then replace it with that
            return toBeDeleted.getLeft();
        }
        else if(toBeDeleted.hasRight() && !toBeDeleted.hasLeft()){ //similar to above
            return toBeDeleted.getRight();
        }
        else{ //if to be deleted node has two children
            AVLTreeNode successor = toBeDeleted.getRight(); //gets the successor which will replace to be deleted node
            AVLTreeNode beforeSuccessor = toBeDeleted; //get before successor node so as to get rid of successor nodes old place
            //Successor is the left most node from the right subtree
            if (successor.hasLeft()){
                beforeSuccessor = beforeSuccessor.getRight();
                successor = successor.getLeft();
            }
            while (successor.hasLeft()){
                successor = successor.getLeft();
                beforeSuccessor = beforeSuccessor.getLeft();
            }
            //if there is a succesor node that is not just to the right of the to be deleted node
            if (beforeSuccessor.getKey() != toBeDeleted.getKey()){
                beforeSuccessor.setLeft(successor.getRight()); //set the left of the parent of successor to the right of successor node sp as to not lose any nodes
                toBeDeleted.changeNodeDet(successor); //change the details of to be deleted node
            }
            else{
                successor.setLeft(toBeDeleted.getLeft()); //change the left node of successor to left node of deleted so as to not leave out nodes
                return successor; //return successor
            }

        }

        return toBeDeleted;
    }

    //Method that checks for imbalances and then proceeds to fix them
    public static AVLTreeNode checkBalance(Stack<AVLTreeNode> stackBalance, AVLTreeNode root){
        AVLTreeNode insertedNode = stackBalance.peek(); //Gets last node in the path to down to inserted or deleted node
        AVLTreeNode currStackNode; //current node working with from stack
        AVLTreeNode beforeImbalanceNode = root; //gets node before the imbalanced node so as to know where to place rebalanced node
        for (int i = (stackBalance.size()-1); i >= 0; i--){ //loop to go through stack from bottom to top
            currStackNode = stackBalance.get(i); //gets nodes starting from bottom of path
            if (i>0){ //if not at root node

                beforeImbalanceNode = stackBalance.get(i-1); //before imbalance node set as node just before current node
            }
            if (currStackNode.getBalanceFactor() > 1){ //if balance factor is greater than 1, then rebalance on left
                if (i == 0){ //if at root node
                    //change root node and return new root
                    AVLTreeNode newRootNode = rebalanceLeft(currStackNode, currStackNode.getLeft().getKey());
                    return newRootNode;
                }
                else{ //if not at root
                    //if the current working node's key is smaller then its parent then the parent should set its left to be the new rebalanced node
                    if (beforeImbalanceNode.getKey() >= currStackNode.getKey() ){
                        beforeImbalanceNode.setLeft(rebalanceLeft(currStackNode, currStackNode.getLeft().getKey()));
                    }
                    else{ //if current nodes key is smaller than parent then set on right
                        beforeImbalanceNode.setRight(rebalanceLeft(currStackNode, currStackNode.getLeft().getKey()));
                    }

                }
                break;
            }
            else if (currStackNode.getBalanceFactor() < -1){ //similar to rebalancing left but balance factor would have been negative
                if (i == 0){
                    AVLTreeNode newRootNode = rebalanceRight(currStackNode, currStackNode.getRight().getKey());
                    return newRootNode;
                }
                else{
                    if (beforeImbalanceNode.getKey() <= currStackNode.getKey()){
                        beforeImbalanceNode.setRight(rebalanceRight(currStackNode, currStackNode.getRight().getKey()));
                    }
                    else{
                        beforeImbalanceNode.setLeft(rebalanceRight(currStackNode, currStackNode.getRight().getKey()));
                    }

                }
            }
        }
        //returns root
        return stackBalance.get(0);
    }


    //rebalances left
    public static AVLTreeNode rebalanceLeft(AVLTreeNode ancestor,int parentKey){
        //if middle node has a left child then do a single rotate left
        if (ancestor.getLeft().hasLeft()){
            return rotateWithLeftChild(ancestor);
        }
        else{ //else do a double rotate
            return doubleRotateWithLeftChild(ancestor);
        }
    }
    //Rebalances Right - similar to left
    public static AVLTreeNode rebalanceRight(AVLTreeNode ancestor,int parentKey){

        if (ancestor.getRight().hasRight()){
            return rotateWithRightChild(ancestor);
        }
        else{
            return doubleRotateWithRightChild(ancestor);
        }
    }


    /**
     * Rotate binary tree node with left child.
     * This is a single rotation for case 1.
     */
    public static AVLTreeNode rotateWithLeftChild( AVLTreeNode AVLk2 ) {

        AVLTreeNode AVLk1 = AVLk2.getLeft(); //sets middle node of three nodes as k1
        AVLk2.setLeft(AVLk1.getRight()); //sets top node to take current children of middle node since they will switch places
        AVLk1.setRight(AVLk2); //set the right of middle node to the top node
        //returns new rebalanced node
        return AVLk1;
    }

    /**
     * Rotate binary tree node with right child.
     * This is a single rotation for case 4.
     */
    public static AVLTreeNode rotateWithRightChild( AVLTreeNode AVLk1 ) {
        //similar to left
        AVLTreeNode AVLk2 = AVLk1.getRight();
        AVLk1.setRight(AVLk2.getLeft());
        AVLk2.setLeft(AVLk1);

        return AVLk2;
    }

    /**
     * Double rotate binary tree node: first rotate k3's left child
     * with its right child; then rotate node k3 with the new left child.
     * This is a double rotation for case 2.
     */
    public static AVLTreeNode doubleRotateWithLeftChild( AVLTreeNode AVLk3 ) {
        AVLk3.setLeft(rotateWithRightChild(AVLk3.getLeft())); //rotate with right child will change the three node values to be all smaller than each other in a row in the tree
        return rotateWithLeftChild(AVLk3); //do a single rotation

    }

    /**
     * Double rotate binary tree node: first rotate k1's right child
     * with its left child; then rotate node k1 with the new right child.
     * This is a double rotation for case 3.
     */
    public static AVLTreeNode doubleRotateWithRightChild( AVLTreeNode AVLk3 )
    {   //similar to left
        AVLk3.setRight(rotateWithLeftChild(AVLk3.getRight()));
        return rotateWithRightChild(AVLk3);
    }

    //method that will return a list of nodes in the first level
    public static AVLTreeNode[] createLvlZero(AVLTreeNode root){
        AVLTreeNode[] levelZero = new AVLTreeNode[1];
        levelZero[0] = root;
        return levelZero;
    }

    //Method to create a Arraylist that contains a list for each level in a Binary Tree
    public static ArrayList createSubTreeList(AVLTreeNode[] parentList){
        AVLTreeNode currentTree = parentList[0]; //Gets root Node from List
        int height = height(currentTree);//Gets height of Binary Tree

        LinkedList NodesQueue = new LinkedList(); //Linked list used to contain Nodes in a Tree in a Queue format
        LinkedList numNodesInLevel = new LinkedList(); //Keeps the number of nodes that are supposed to be in a level
        ArrayList NodeLevels = new ArrayList(); //will keep all levels of node, Main list which will have inner lists

        for (int i = 0; i < height; i++){
            int noOfNodes = (int) Math.pow(2,i); //Calculates number of nodes in each level
            numNodesInLevel.add(noOfNodes); //Adds number to linkedlist so as to use later
            NodeLevels.add(new ArrayList()); //Create a list for every level, Put into main list
        }
        NodesQueue.add(currentTree); //Adds root node into Linked List. Will work with it first

        //While loop will retrieve and delete first item in linked list Queue and work with that item for current loop
        //Then it will add that Tree Node to appropriate Node level List, eg root node into Level 0 Arraylist
        //After this it will determine if there are left or right sub trees, if there are it will add that subtree
        //node to the Linked List Queue with Left preferenced.

        int count = 0; //Determines which Level List should be on by using the numNodesInLevel list
        int currNodeLevel = 0;//Index for the Node level list
        ArrayList currAryList; //current working Arraylist

        while(currNodeLevel < height){ //Goes until it reaches end of last level
            count = count + 1;
            AVLTreeNode currTreeNode = (AVLTreeNode) NodesQueue.pop();
            currAryList = (ArrayList) (NodeLevels.get(currNodeLevel));
            currAryList.add(currTreeNode);
            if (currTreeNode == null){ //For the placeholder Nodes, if a placeholder then create placeholder children

                NodesQueue.add(null);//have to create placeholder children to space
                NodesQueue.add(null);//it out appropriately for printing algorithm
            }
            else { //if legit Node, (Node != null)

                if (currTreeNode.hasLeft()) {
                    NodesQueue.add(currTreeNode.getLeft());//add Left sub tree to Queue so it can be processed later
                }
                else {
                    NodesQueue.add(null); //if no left tree, put a placeholder
                }

                if (currTreeNode.hasRight()) {
                    NodesQueue.add(currTreeNode.getRight()); //same as left
                }
                else {
                    NodesQueue.add(null);
                }

            }

            //if the number of nodes added so far in the loop equal to what the number
            //of nodes in a level should be then reset counter and start adding till
            //the number of nodes equal the next levels predicted number of nodes

            if (count == numNodesInLevel.peek()) {
                currNodeLevel = currNodeLevel + 1; //New level of Tree
                count = 0; //reset counter
                numNodesInLevel.pop(); //remove old levels Node number(number of nodes in that level)
            }

        } //end of while loop

        return NodeLevels; //returns arraylist containing lists of every level
    }

    
}
